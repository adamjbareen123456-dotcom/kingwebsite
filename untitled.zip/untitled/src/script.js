function changeStyle() {
    let title = document.getElementById("title");
    title.style.fontSize = "6vw";
    title.style.color = "#ffeb3b";
    title.style.textTransform = "uppercase";
    alert("king your uncle");
}
function changeStyle() {
  let title = document.getElementById("title");
  title.style.fontSize = "6vw";
  title.style.color = "#ffeb3b";
  title.style.textTransform = "uppercase";
  alert("تم تغيير النمط 🎉");
}

function toggleTheme() {
  let body = document.body;
  if (body.classList.contains("dark")) {
    body.classList.remove("dark");
    body.classList.add("light");
  } else if (body.classList.contains("light")) {
    body.classList.remove("light");
    body.classList.add("dark");
  } else {
    body.classList.add("dark"); // البداية دايماً غامق إذا ما كان محدد
  }
}
